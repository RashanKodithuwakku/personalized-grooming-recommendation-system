import cv2
import numpy as np

def create_before_after(original_photo, preview_photo):
    """
    Original photo eka saha preview eka, side-by-side ekathu karanawa.
    Dekama images, height ekamama widiyata resize karala, horizontal widiyata join karanawa.
    """
    h1, w1 = original_photo.shape[:2]
    h2, w2 = preview_photo.shape[:2]
    
    # Dekama images, ekama height ekatama resize karanawa (width proportionally adjust wenawa)
    target_height = min(h1, h2)
    
    original_resized = cv2.resize(original_photo, (int(w1 * target_height / h1), target_height))
    preview_resized = cv2.resize(preview_photo, (int(w2 * target_height / h2), target_height))
    
    # Small gap ekak, dekak atharē (visual separation ekata)
    gap = np.ones((target_height, 10, 3), dtype=np.uint8) * 255
    
    combined = np.hstack([original_resized, gap, preview_resized])
    return combined