import sqlite3
from datetime import datetime

DB_PATH = "feedback.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            style_shown TEXT,
            variant_shown TEXT,
            feedback_value TEXT,
            timestamp TEXT
        )
    """)
    conn.commit()
    conn.close()
    print("Database initialized successfully")

def save_feedback(user_id, style_shown, variant_shown, feedback_value):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO feedback (user_id, style_shown, variant_shown, feedback_value, timestamp)
        VALUES (?, ?, ?, ?, ?)
    """, (user_id, style_shown, variant_shown, feedback_value, str(datetime.now())))
    conn.commit()
    conn.close()
    
    return {
        "user_id": user_id,
        "style_shown": style_shown,
        "variant_shown": variant_shown,
        "feedback": feedback_value,
        "timestamp": str(datetime.now())
    }

def get_all_feedback():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM feedback")
    results = cursor.fetchall()
    conn.close()
    return results