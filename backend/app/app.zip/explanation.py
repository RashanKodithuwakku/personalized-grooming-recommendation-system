def generate_explanation(attribution_data):
    factors = attribution_data.get("contributing_factors", {})
    if not factors:
        return "This style was recommended based on your facial profile."
    
    top_factor = max(factors, key=factors.get)
    confidence = int(attribution_data.get("confidence", 0) * 100)
    
    return f"Recommended because of your {top_factor} — {confidence}% confidence match."