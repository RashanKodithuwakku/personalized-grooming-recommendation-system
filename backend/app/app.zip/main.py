import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import shutil
import cv2

from main_flow import generate_preview, process_feedback, process_advanced_preview_choice
from database import init_db
from segmentation import load_bisenet_model

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()
bisenet_model = load_bisenet_model("../face-parsing.PyTorch/res/cp/79999_iter.pth")


@app.post("/generate-preview")
async def generate_preview_endpoint(
    file: UploadFile = File(...),
    gender: str = "male",
    style_type: str = "hairstyle",   # ALUTH PARAMETER - "hairstyle" ho "beard"
    current_rank: int = 1
):
    """
    User ge photo eka upload karala, style preview ekak generate karanawa.
    style_type: "hairstyle" ho "beard" - user eken select karana category eka
    """
    file_path = f"test_photos/{file.filename}"
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    result = generate_preview(
        user_id="test_user",
        user_photo_path=file_path,
        gender=gender,
        style_type=style_type,
        current_rank=current_rank,
        bisenet_model=bisenet_model
    )

    return result


class FeedbackRequest(BaseModel):
    user_id: str
    current_rank: int
    feedback_value: str
    style_shown: str
    variant_shown: str
    gender: str
    style_type: str   # ALUTH FIELD

@app.post("/feedback")
async def submit_feedback(request: FeedbackRequest):
    """
    User ge like/dislike feedback eka ganna, database ekata save karala,
    passe karanna ona action eka (next style / advanced preview popup) decide karanawa.
    """
    result = process_feedback(
        user_id=request.user_id,
        current_rank=request.current_rank,
        feedback_value=request.feedback_value,
        style_shown=request.style_shown,
        variant_shown=request.variant_shown,
        gender=request.gender,
        style_type=request.style_type
    )
    return result


class AdvancedPreviewRequest(BaseModel):
    wants_advanced: bool

@app.post("/advanced-preview-choice")
def advanced_preview_choice(request: AdvancedPreviewRequest):
    """
    User, 'Like' dunna passe, advanced preview ekak ona da kiyana 
    popup ekata, Yes/No response eka ganna endpoint eka.
    """
    result = process_advanced_preview_choice(request.wants_advanced)
    return result